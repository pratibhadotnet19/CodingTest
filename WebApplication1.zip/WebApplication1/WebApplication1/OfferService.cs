﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication1
{
    public class OfferService
    {
        public static class Inventory
        {
            public static List<Product> products;
            public static List<Product> Products
            {
                get
                 {
                    if (products.Count == 0)
                    {
                        Product item1 = new Product("P1",1000, "P1 desc");
                        Product item2 = new Product("P2", 200, "P2 desc");
                        Product item3 = new Product("P3", 400, "P3 desc");
                        Product item4 = new Product("P4", 700, "P4 desc");
                        Product item5 = new Product("P5", 600, "P5 desc");
                        Product item6 = new Product("P6", 800, "P6 desc");
                    }
                    return products;

                }
                set { products = value; }
            }
            static Inventory()
            {
                Products = new List<Product>();
            }
          
           
        }
        public IEnumerable<Product> GetAllProducts()
        {
            return Inventory.Products;
        }
        public dynamic GetTodaysOffers()
        { 
        
        }
    }
}
