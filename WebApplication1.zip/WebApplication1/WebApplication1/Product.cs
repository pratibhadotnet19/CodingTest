﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication1
{
    public class Product
    {
        public string ProductName;
        public decimal Price;
        public string Description;

        public Product(string ProductName,decimal Price,string Description) {
            setPName(ProductName);
            setPrice(Price);
            setDescription(Description);
        }
        public void setPName(string ProductName) {
            ProductName = ProductName;
        }
        public void setPrice(decimal Price) { Price = Price; }
        public void setDescription(string Description) { Description = Description; }
    }
}
